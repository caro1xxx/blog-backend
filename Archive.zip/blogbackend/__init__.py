import pymysql
pymysql.install_as_MySQLdb()